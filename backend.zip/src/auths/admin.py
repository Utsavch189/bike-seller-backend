from django.contrib import admin
from src.auths.models import Client

admin.site.register(Client)
