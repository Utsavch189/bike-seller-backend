from django.contrib import admin
from .models import Bike,BikeMeta,BikeImages

admin.site.register(Bike)
admin.site.register(BikeMeta)
admin.site.register(BikeImages)